from django.urls import path
from . import views  # Ensure you are importing your views correctly

urlpatterns = [
    path('', views.job_application_form, name='job_application_form'),
    path('junior-accountant/', views.junior_accountant, name='junior_accountant'),
    path('senior-accountant/', views.senior_accountant, name='senior_accountant'),
    path('it/', views.it, name='it'),
    path('back-office/', views.back_office, name='back_office'),
    path('hrm/', views.hrm, name='hrm'),
    path('crm/', views.crm, name='crm'),
    path('result/', views.result, name='result'),
    path('reset-quiz/', views.reset_quiz, name='reset_quiz'),
]
