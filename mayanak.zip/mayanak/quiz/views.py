from django.shortcuts import render
from .forms import JobApplicationForm 
from django.shortcuts import render, redirect
from .forms import JobApplicationForm
from .models import JuniorAccountant,SeniorAccountant,It,Crm,BackOffice,Hrm

def job_application_form(request):
    if request.method == 'POST':
        form = JobApplicationForm(request.POST)
        if form.is_valid():
            form.save()
            request.session['completed'] = False  # 'completed' को False सेट करें

            position = form.cleaned_data['position_apply_for']
            if position == 'junior_accountant': 
                return redirect('junior_accountant')
            elif position == 'senior_accountant':
                return redirect('senior_accountant')
            elif position == 'it':
                return redirect('it')
            elif position == 'back_office':
                return redirect('back_office')
            elif position == 'hrm':
                return redirect('hrm')
            elif position == 'crm':
                return redirect('crm')
    else:
        form = JobApplicationForm()
    
    return render(request, 'quiz/job_application_form.html', {'form': form})


def junior_accountant(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = JuniorAccountant.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('junior_accountant')

    return render(request, 'quiz/junior_accountant.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def result(request):
    if 'completed' not in request.session or not request.session['completed']:
        return redirect('junior_accountant')

    answers = request.session.get('answers', [])
    correct_count = sum(1 for ans in answers if ans['user_answer'] == ans['correct_answer'])
    total_questions = len(answers)
    incorrect_count = total_questions - correct_count

    percentage = (correct_count / total_questions) * 100 if total_questions > 0 else 0

    return render(request, 'quiz/result.html', {
        'correct_count': correct_count,
        'incorrect_count': incorrect_count,
        'percentage': percentage,
        'total_questions': total_questions
    })


def reset_quiz(request):
    request.session['completed'] = False
    request.session['question_index'] = 0
    request.session['answers'] = []
    return redirect('job_application_form')


def it(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = It.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('it')

    return render(request, 'quiz/it.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def senior_accountant(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = SeniorAccountant.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('senior_accountant')

    return render(request, 'quiz/senior_accountant.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })


def hrm(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = Hrm.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('hrm')

    return render(request, 'quiz/hrm.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def crm(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = Crm.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('crm')

    return render(request, 'quiz/crm.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

def back_office(request):
    if 'completed' in request.session and request.session['completed']:
        return redirect('result')

    questions = BackOffice.objects.all()
    
    question_index = request.session.get('question_index', 0)

    if question_index >= len(questions):
        request.session['completed'] = True
        return redirect('result')

    current_question = questions[question_index]
    
    correct_answer = current_question.correct_option
    
    if request.method == 'POST':
        user_answer = request.POST.get('answer')

        answers = request.session.get('answers', [])
        answers.append({
            'question': current_question.question,
            'user_answer': user_answer,
            'correct_answer': correct_answer
        })
        request.session['answers'] = answers
        
        request.session['question_index'] = question_index + 1
        
        return redirect('back_office')

    return render(request, 'quiz/backoffice.html', {
        'question': current_question,
        'question_index': question_index,
        'time_limit': 20
    })

